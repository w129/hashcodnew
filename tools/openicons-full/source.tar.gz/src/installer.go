package main

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"sort"
	"strings"
	"sync"
)

type installProgress struct {
	Running   bool   `json:"running"`
	Phase     string `json:"phase"`
	Total     int    `json:"total"`
	Finished  int    `json:"finished"`
	Installed int    `json:"installed"`
	Skipped   int    `json:"skipped"`
	Failed    int    `json:"failed"`
	LastError string `json:"lastError,omitempty"`
}

func (a *application) installStatus(w http.ResponseWriter, r *http.Request) {
	a.installerMu.Lock()
	status := a.installer
	a.installerMu.Unlock()
	getJSON(w, status)
}
func (a *application) installStart(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		errJSON(w, "Método no permitido", 405)
		return
	}
	a.installerMu.Lock()
	if a.installer.Running {
		a.installerMu.Unlock()
		errJSON(w, "La instalación ya está ejecutándose", 409)
		return
	}
	a.installer = installProgress{Running: true, Phase: "Consultando colecciones oficiales de Iconify"}
	a.installerMu.Unlock()
	go a.installAll(context.Background())
	getJSON(w, map[string]any{"started": true})
}
func (a *application) reportInstall(update func(*installProgress)) {
	a.installerMu.Lock()
	update(&a.installer)
	a.installerMu.Unlock()
}
func (a *application) installAll(ctx context.Context) {
	defer a.reportInstall(func(s *installProgress) { s.Running = false; s.Phase = "Finalizado" })
	metaBytes, err := fetchRemote(ctx, apiBase+"/collections", maxAPI)
	if err != nil {
		a.reportInstall(func(s *installProgress) {
			s.LastError = "No se pudo obtener el catálogo oficial: " + err.Error()
			s.Phase = "Sin conexión"
		})
		return
	}
	var available map[string]json.RawMessage
	if err := json.Unmarshal(metaBytes, &available); err != nil || len(available) == 0 || len(available) > 2500 {
		a.reportInstall(func(s *installProgress) {
			s.LastError = "Respuesta inválida del índice de Iconify"
			s.Phase = "Error"
		})
		return
	}
	keys := make([]string, 0, len(available))
	for key := range available {
		if isKey(key) {
			keys = append(keys, key)
		}
	}
	sort.Strings(keys)
	a.reportInstall(func(s *installProgress) { s.Total = len(keys); s.Phase = "Instalando colecciones para uso local" })
	jobs := make(chan string)
	var wg sync.WaitGroup
	for worker := 0; worker < 4; worker++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for key := range jobs {
				_, err := os.Stat(a.file("packs", key))
				if _, bundled := bundledInfo[key]; bundled || err == nil {
					a.reportInstall(func(s *installProgress) { s.Skipped++; s.Finished++ })
					continue
				}
				set, err := a.downloadForOffline(ctx, key, available[key])
				if err != nil {
					a.reportInstall(func(s *installProgress) {
						s.Failed++
						s.Finished++
						if s.LastError == "" {
							s.LastError = fmt.Sprintf("%s: %v", key, err)
						}
					})
				} else {
					_ = set
					a.reportInstall(func(s *installProgress) { s.Installed++; s.Finished++ })
				}
			}
		}()
	}
	for _, key := range keys {
		jobs <- key
	}
	close(jobs)
	wg.Wait()
}
func (a *application) downloadForOffline(ctx context.Context, prefix string, metadata json.RawMessage) (*iconSet, error) {
	if !isKey(prefix) {
		return nil, fmt.Errorf("prefijo inválido")
	}
	urls := []string{cdnBase + "/" + url.PathEscape(prefix) + "/icons.json", "https://raw.githubusercontent.com/iconify/icon-sets/master/json/" + url.PathEscape(prefix) + ".json"}
	var last error
	for _, endpoint := range urls {
		contents, err := fetchRemote(ctx, endpoint, maxPack)
		if err != nil {
			last = err
			continue
		}
		set, err := validateSet(contents, prefix)
		if err != nil {
			last = err
			continue
		}
		names := packNames(set)
		if err := atomicWrite(a.file("packs", prefix), contents); err != nil {
			return nil, err
		}
		listed, _ := json.Marshal(map[string]any{"prefix": prefix, "icons": names, "total": len(names), "offline": true})
		if err := atomicWrite(a.file("lists", prefix), listed); err != nil {
			return nil, err
		}
		var info map[string]any
		if json.Unmarshal(metadata, &info) != nil || info == nil {
			info = map[string]any{}
		}
		info["total"] = len(names)
		if _, ok := info["name"]; !ok {
			info["name"] = prefix
		}
		if b, err := json.Marshal(info); err == nil {
			_ = atomicWrite(a.file("meta", "pack-"+prefix), b)
		}
		// Keep the packed collection on disk, but avoid holding hundreds of
		// decoded icon sets in RAM during the bulk import.
		return set, nil
	}
	if last == nil {
		last = fmt.Errorf("sin origen disponible")
	}
	return nil, fmt.Errorf("%s", strings.TrimSpace(last.Error()))
}
