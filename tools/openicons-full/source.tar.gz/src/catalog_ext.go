package main

import (
	"encoding/json"
	"os"
	"sort"
	"strings"
)

// The original full icon bodies are loaded only for an icon that is viewed;
// search, counts and browsing use compact name lists for installed packs.
func (a *application) installedPrefixes() []string {
	entries, _ := os.ReadDir(a.folder("packs"))
	keys := make([]string, 0, len(entries))
	for _, item := range entries {
		if item.IsDir() || !strings.HasSuffix(item.Name(), ".json") {
			continue
		}
		key := strings.TrimSuffix(item.Name(), ".json")
		if !isKey(key) {
			continue
		}
		if _, already := bundledInfo[key]; already {
			continue
		}
		keys = append(keys, key)
	}
	sort.Strings(keys)
	return keys
}
func (a *application) namesFor(prefix string) []string {
	if b, err := os.ReadFile(a.file("lists", prefix)); err == nil {
		var list struct {
			Icons []string `json:"icons"`
		}
		if json.Unmarshal(b, &list) == nil && len(list.Icons) > 0 {
			return list.Icons
		}
	}
	set, err := a.getPack(prefix)
	if err != nil {
		return nil
	}
	names := packNames(set)
	b, _ := json.Marshal(map[string]any{"prefix": prefix, "icons": names, "total": len(names), "offline": true})
	_ = atomicWrite(a.file("lists", prefix), b)
	return names
}
func (a *application) localNameIndex() (map[string][]string, error) {
	index, err := bundledSearchIndex()
	if err != nil {
		return nil, err
	}
	all := make(map[string][]string, len(index)+200)
	for k, v := range index {
		all[k] = v
	}
	for _, key := range a.installedPrefixes() {
		if _, exists := all[key]; !exists {
			if names := a.namesFor(key); len(names) > 0 {
				all[key] = names
			}
		}
	}
	return all, nil
}
func (a *application) importedCatalog() map[string]json.RawMessage {
	out := map[string]json.RawMessage{}
	for _, key := range a.installedPrefixes() {
		names := a.namesFor(key)
		if len(names) == 0 {
			continue
		}
		info := map[string]any{"name": key, "total": len(names)}
		if b, err := os.ReadFile(a.file("meta", "pack-"+key)); err == nil {
			var stored map[string]any
			if json.Unmarshal(b, &stored) == nil && stored != nil {
				for k, v := range stored {
					info[k] = v
				}
			}
		}
		info["total"] = len(names)
		if b, err := json.Marshal(info); err == nil {
			out[key] = b
		}
	}
	return out
}
