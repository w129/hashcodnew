package main

import (
	"net/http"
	"sort"
	"strconv"
)

// A variant is a styled version of a genuine SVG in the installed catalog.
// The gallery interleaves DISTINCT source drawings across every page instead
// of showing 400 recolored copies of one icon before moving to the next.
var variantColors = []string{"#17191d", "#f8fafc", "#00b894", "#3b82f6", "#a855f7", "#f43f5e", "#f59e0b", "#ef4444", "#06b6d4", "#64748b"}
var variantBackgrounds = []string{"transparent", "#ffffff", "#121212", "#a0e2c5", "#dbeafe", "#ede9fe", "#fef3c7", "#ffe4e6", "#e2e8f0", "#1e293b"}
var variantRotations = []int{0, 90, 180, 270}

const variantsPerIcon = 400

type iconOrder struct {
	names      map[string][]string
	prefixes   []string
	cumulative []int
	total      int
	stride     int
}

func gcd(a, b int) int {
	for b != 0 {
		a, b = b, a%b
	}
	return a
}
func newIconOrder(names map[string][]string) *iconOrder {
	v := &iconOrder{names: names}
	for prefix := range names {
		v.prefixes = append(v.prefixes, prefix)
	}
	sort.Strings(v.prefixes)
	for _, prefix := range v.prefixes {
		v.total += len(names[prefix])
		v.cumulative = append(v.cumulative, v.total)
	}
	if v.total > 0 {
		// Spread successive gallery items across the WHOLE library. A coprime
		// step visits each icon exactly once before repeating any drawing.
		v.stride = int(float64(v.total) * 0.6180339887498948)
		if v.stride < 1 {
			v.stride = 1
		}
		for gcd(v.stride, v.total) != 1 {
			v.stride++
		}
	}
	return v
}
func (v *iconOrder) at(i int) (string, bool) {
	if i < 0 || i >= v.total {
		return "", false
	}
	p := sort.SearchInts(v.cumulative, i+1)
	local := i
	if p > 0 {
		local -= v.cumulative[p-1]
	}
	return v.prefixes[p] + ":" + v.names[v.prefixes[p]][local], true
}

// sortedIndexWindow is the standard sequential browser order (not the shuffled variant order).
func sortedIndexWindow(names map[string][]string, start, count int) ([]string, int) {
	order := newIconOrder(names)
	if start < 0 {
		start = 0
	}
	if start > order.total {
		start = order.total
	}
	out := make([]string, 0, count)
	for i := start; i < order.total && len(out) < count; i++ {
		if k, ok := order.at(i); ok {
			out = append(out, k)
		}
	}
	return out, order.total
}

func (v *iconOrder) variant(pos int64) (map[string]any, bool) {
	total := int64(v.total)
	if total == 0 || pos < 0 || pos >= total*variantsPerIcon {
		return nil, false
	}
	baseIdx := int(((pos % total) * int64(v.stride)) % total)
	key, ok := v.at(baseIdx)
	if !ok {
		return nil, false
	}
	// Variation numbers are rotated by drawing, keeping each page visually
	// diverse while preserving all 400 combinations for EVERY source icon.
	variant := (int(pos/total) + (baseIdx*97)%variantsPerIcon) % variantsPerIcon
	return map[string]any{
		"key": key, "variant": variant, "color": variantColors[variant%10],
		"rotation": variantRotations[(variant/10)%4], "background": variantBackgrounds[(variant/40)%10],
	}, true
}

// Exposed to tests to check every style without loading the full catalog.
func variantAt(pos int64, a *application) (string, int, int, bool) {
	names, err := a.localNameIndex()
	if err != nil {
		return "", 0, 0, false
	}
	order := newIconOrder(names)
	item, ok := order.variant(pos)
	if !ok {
		return "", 0, order.total, false
	}
	return item["key"].(string), item["variant"].(int), order.total, true
}
func (a *application) variants(w http.ResponseWriter, r *http.Request) {
	offset, _ := strconv.ParseInt(r.URL.Query().Get("start"), 10, 64)
	if offset < 0 {
		offset = 0
	}
	names, err := a.localNameIndex()
	if err != nil {
		errJSON(w, "Índice de variantes no disponible", 500)
		return
	}
	order := newIconOrder(names)
	total := int64(order.total) * variantsPerIcon
	if offset > total {
		offset = total
	}
	items := make([]map[string]any, 0, 72)
	for i := int64(0); i < 72 && offset+i < total; i++ {
		if item, ok := order.variant(offset + i); ok {
			items = append(items, item)
		}
	}
	getJSON(w, map[string]any{"variants": items, "start": offset, "total": total, "distinctIcons": order.total, "variantsPerIcon": variantsPerIcon})
}
