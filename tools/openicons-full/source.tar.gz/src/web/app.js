/* Openicons by Hashcod — client interactions. MIT license. */
'use strict';
const $ = id => document.getElementById(id);
const featured = [
  ['lucide','Lucide','L'],['tabler','Tabler Icons','T'],['ph','Phosphor','P'],
  ['iconoir','Iconoir','I'],['material-symbols','Material Symbols','M'],
  ['mdi','Material Design Icons (offline)','MD'],['hashcod','Hashcod Originals','H']
];
const state = {
  prefix:'hashcod',nav:'collection',collection:[],search:'',all:[],page:0,pageSize:72,
  selected:'',collections:{},offline:{hashcod:25},favorites:new Set(),color:'#17191d',theme:'dark',rotation:0,background:'transparent',
  mode:'collection',total:0,loading:false,requestId:0,globalResult:[],globalStart:0,searchTotal:0,paletteTarget:'icon',variantOffset:0
};
const asString=v=>String(v??'');
const esc=v=>asString(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const simpleKey=s=>/^[a-z0-9][a-z0-9_-]{0,99}$/.test(s);
const splitKey=key=>{const pos=key.indexOf(':');return pos>0&&simpleKey(key.slice(0,pos))&&simpleKey(key.slice(pos+1))?[key.slice(0,pos),key.slice(pos+1)]:null};
const nice=n=>Number(n||0).toLocaleString('es-DO');
function selectValueOrCustom(id,value){const select=$(id);if(![...select.options].some(opt=>opt.value===value)){let opt=select.querySelector('option[data-custom]');if(!opt){opt=document.createElement('option');opt.dataset.custom='true';select.add(opt)}opt.value=value;opt.textContent='Personalizado '+value;}select.value=value;}
const short=n=>n>=1e6?`${(n/1e6).toFixed(n>=1e7?0:2)}M`:n>=1000?`${(n/1000).toFixed(n>=10000?0:1)}k`:String(n||0);
const svgIcon=(id,extra='')=>`<svg ${extra}><use href="#i-${id}"/></svg>`;
let toastTimer=null,searchTimer=null,saveTimer=null;
function notify(text){const t=$('toast');t.textContent=text;t.classList.remove('hidden');clearTimeout(toastTimer);toastTimer=setTimeout(()=>t.classList.add('hidden'),3100)}
function message(text,type=''){const el=$('message');el.textContent=text;el.className='message'+(type?' '+type:'');}
function hideMessage(){$('message').classList.add('hidden')}
async function getJSON(path,options={}){
 const response=await fetch(path,{cache:'no-store',...options});
 let obj;try{obj=await response.json()}catch{throw new Error('Respuesta del servidor inválida')}
 if(!response.ok)throw new Error(obj.error||`HTTP ${response.status}`);
 return obj;
}
function setLoading(yes){state.loading=yes;$('loading').classList.toggle('hidden',!yes)}
function serialize(){return {favorites:Array.from(state.favorites),theme:state.theme,color:state.color,rotation:state.rotation,background:state.background}}
function saveState(){clearTimeout(saveTimer);saveTimer=setTimeout(()=>fetch('/api/state',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(serialize())}).catch(()=>{}),250)}
async function loadState(){try{const x=await getJSON('/api/state');if(Array.isArray(x.favorites))state.favorites=new Set(x.favorites.filter(e=>!!splitKey(e)));if(x.theme==='light'||x.theme==='dark')state.theme=x.theme;if(/^#[\da-f]{6}$/i.test(x.color||''))state.color=x.color;if([0,90,180,270].includes(x.rotation))state.rotation=x.rotation;if(x.background==='transparent'||/^#[\da-f]{6}$/i.test(x.background||''))state.background=x.background;}catch{}document.documentElement.classList.toggle('light',state.theme==='light');$('colorPicker').value=state.color;$('rotationSelect').value=String(state.rotation);selectValueOrCustom('backgroundSelect',state.background);selectValueOrCustom('paletteSelect',state.color);updateFavoritesCount();applyVariantPreview();syncColorControls();}
function updateFavoritesCount(){$('favCount').textContent=nice(state.favorites.size)}
async function refreshOffline(){try{const res=await getJSON('/api/offline');state.offline=res.collections||{hashcod:25};$('offlineCount').textContent=Object.keys(state.offline).length;const total=Object.values(state.offline).reduce((a,b)=>a+Number(b),0);$('cacheState').textContent=nice(total)+' diseños incorporados · sin internet';renderSets();if(state.nav==='collection')updateViewInfo()}catch{}}
async function refreshCatalog(){
 try{const obj=await getJSON('/api/collections');state.collections=obj;
   const keys=Object.keys(obj);$('setsCount').textContent=nice(keys.length);$('statSets').textContent=nice(keys.length);
   let total=keys.reduce((s,k)=>s+Number(obj[k]?.total||0),0);
   $('statIcons').textContent=nice(total);$('allCount').textContent=short(total);
   const stats=await getJSON('/api/statistics');$('statVariants').textContent=(stats.variantCombinations/1000000).toFixed(2)+'M';$('variantCount').textContent=short(stats.variantCombinations);
   const amount=nice(stats.distinctIcons);$('installedStatus').textContent=stats.fullCatalogBundled?`${amount} iconos realmente incluidos en este EXE, disponibles sin Internet.`:`${amount} iconos disponibles sin Internet. Para agregar las colecciones de Iconify, pulsa «Instalar catálogo completo» (conexión necesaria solo una vez).`;
   $('statusDot').classList.remove('offline');$('networkState').textContent='Biblioteca local lista';renderSets();}
 catch(e){$('statusDot').classList.add('offline');$('networkState').textContent='Error en el catálogo local';message('No se pudo leer el catálogo local: '+e.message,'error');renderSets()}
}

function itemFor(prefix,meta){
 const data=meta||state.collections[prefix]||{};const known=featured.find(x=>x[0]===prefix);
 return {prefix,name:known?.[1]||data.name||data.title||prefix.toUpperCase(),letter:known?.[2]||prefix.slice(0,2).toUpperCase(),total:data.total||state.offline[prefix]||0};
}
function createSetItem(prefix,meta){const x=itemFor(prefix,meta);const active=state.nav==='collection'&&state.prefix===prefix;return `<button class="set-item${active?' active':''}" data-prefix="${esc(prefix)}" title="${esc(x.name)}"><span class="set-icon">${esc(x.letter)}</span><span class="set-label">${esc(x.name)}</span>${state.offline[prefix]?'<i class="set-offline" title="Disponible sin conexión"></i>':''}<span class="set-count">${x.total?short(x.total):''}</span></button>`}
function renderSets(){
 $('featuredSets').innerHTML=featured.filter(x=>state.collections[x[0]]||state.offline[x[0]]).map(x=>createSetItem(x[0])).join('');
 const query=$('setFilter').value.trim().toLowerCase();
 const entries=Object.entries(state.collections).filter(([p])=>!featured.some(f=>f[0]===p)).filter(([p,o])=>!query||p.includes(query)||(o.name||o.title||'').toLowerCase().includes(query));
 const cached=Object.keys(state.offline).filter(p=>!state.collections[p]&&!featured.some(f=>f[0]===p)&&(!query||p.includes(query))).map(p=>[p,{}]);
 entries.push(...cached);entries.sort((a,b)=>asString(a[1].name||a[0]).localeCompare(asString(b[1].name||b[0])));
 $('setsList').innerHTML=entries.slice(0,650).map(([prefix,meta])=>createSetItem(prefix,meta)).join('')||'<div style="font-size:11px;color:var(--subtle);padding:11px">No hay colecciones.</div>';
 document.querySelectorAll('[data-prefix]').forEach(b=>b.addEventListener('click',()=>selectCollection(b.dataset.prefix)));
}
function updateNav(){document.querySelectorAll('[data-nav]').forEach(b=>b.classList.toggle('active',b.dataset.nav===state.nav))}
function updateViewInfo(){
 const prefix=state.prefix;const data=itemFor(prefix);const selected=state.nav==='collection';
 $('viewTitle').textContent=selected?data.name:state.nav==='favorites'?'Tus favoritos':state.nav==='offline'?'Biblioteca sin conexión':state.nav==='variants'?'Variaciones de iconos':'Explorar todos los iconos';
 $('crumbActive').textContent=$('viewTitle').textContent;
 const count=state.mode==='search'?state.searchTotal:state.total;
 $('viewCount').textContent=nice(count)+(state.nav==='variants'&&state.mode==='variants'?' variaciones':' diseños');$('variantJumpPanel').classList.toggle('hidden',state.mode!=='variants');if(state.mode==='variants'){$('variantJump').max=String(count);$('variantJumpInfo').textContent='Total: '+nice(count)+' combinaciones · catálogo instalado';}
 $('viewDescription').textContent=selected?'Biblioteca '+prefix+' · SVG incorporados al ejecutable':state.nav==='favorites'?'Tus iconos preferidos':state.nav==='offline'?'Colecciones integradas y guardadas en este equipo':state.nav==='variants'?'400 variaciones exportables por cada diseño: muestra generada al instante':'Explora todos los iconos instalados, sin necesidad de internet';
 $('saveSet').classList.toggle('hidden',true);
 $('offlinePill').classList.toggle('hidden',!selected||!state.offline[prefix]);
 const lic=state.collections[prefix]?.license;
 $('licenseInfo').textContent=selected&&lic?('Licencia: '+(lic.title||lic.spdx||'Consultar')):'';
 $('saveSet').textContent='';$('saveSet').innerHTML=svgIcon('download')+(state.offline[prefix]?' Guardado offline':' Guardar colección');
}
function urlFor(key){const pair=splitKey(key);if(!pair)return '';return `/api/icon?prefix=${encodeURIComponent(pair[0])}&name=${encodeURIComponent(pair[1])}&color=${encodeURIComponent(state.color)}`;}
function redrawCards(){document.querySelectorAll('.icon-card:not(.variant-card)').forEach(card=>{const key=card.dataset.key;card.classList.toggle('selected',state.selected===key);const fav=card.querySelector('.fav-icon');if(fav){fav.classList.toggle('is-fav',state.favorites.has(key));fav.title=state.favorites.has(key)?'Eliminar de favoritos':'Añadir a favoritos'}const img=card.querySelector('img');if(img){img.src=urlFor(key);img.style.transform='rotate('+state.rotation+'deg)'}});if(state.selected){$('previewImage').src=urlFor(state.selected);$('toggleFav').querySelector('#favActionLabel').textContent=state.favorites.has(state.selected)?'Eliminar de favoritos':'Añadir a favoritos'}applyVariantPreview()}
function addGridItems(items,clear=false){
 if(clear)$('iconGrid').innerHTML='';
 if(!items||!items.length){if(clear)$('iconGrid').innerHTML=`<div class="empty">${svgIcon('search')}<strong>No se encontraron iconos</strong>Prueba con otro término o selecciona una colección.</div>`;return}
 const fragment=document.createDocumentFragment();
 for(const key of items){const pair=splitKey(key);if(!pair)continue;const [prefix,name]=pair;const card=document.createElement('article');card.className='icon-card'+(state.selected===key?' selected':'');card.dataset.key=key;
 card.innerHTML=`<button class="fav-icon ${state.favorites.has(key)?'is-fav':''}" title="Favorito" aria-label="Marcar favorito">${svgIcon('heart')}</button><div class="icon-thumb" role="button" tabindex="0" aria-label="Ver ${esc(name)}"><img loading="lazy" decoding="async" alt="${esc(name)}" src="${esc(urlFor(key))}" style="width:${+$('sizeSelect').value}px;height:${+$('sizeSelect').value}px"/></div><div class="card-name" title="${esc(name)}">${esc(name.replaceAll('-',' '))}</div><div class="card-prefix">${esc(prefix)}</div>`;
 card.querySelector('img').style.transform='rotate('+state.rotation+'deg)';card.querySelector('.icon-thumb').addEventListener('click',()=>chooseIcon(key));card.querySelector('.icon-thumb').addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();chooseIcon(key)}});
 card.querySelector('.fav-icon').addEventListener('click',e=>{e.stopPropagation();toggleFavorite(key)});fragment.append(card)
 }
 $('iconGrid').appendChild(fragment)
}
function renderPage(reset=true){
 if(reset){state.page=0;addGridItems([],true);$('iconGrid').innerHTML=''}
 const start=state.page*state.pageSize;const next=state.all.slice(start,start+state.pageSize);
 if(!next.length&&state.page===0)addGridItems([],true);else if(state.mode==='variants')addVariantItems(next);else addGridItems(next,false);
 state.page++;
 $('loadMore').classList.toggle('hidden',state.page*state.pageSize>=state.all.length && !((state.mode==='search'||state.mode==='browse'||state.mode==='variants') && (state.mode==='variants'?state.variantOffset+state.all.length<state.searchTotal:state.all.length<state.searchTotal)));
}
async function selectCollection(prefix){
 if(!simpleKey(prefix))return;state.nav='collection';state.mode='collection';state.prefix=prefix;state.search='';state.requestId++;$('searchInput').value='';$('clearSearch').style.display='none';hideMessage();updateNav();renderSets();setLoading(true);
 const token=state.requestId;try{const res=await getJSON('/api/collection?prefix='+encodeURIComponent(prefix));if(token!==state.requestId)return;state.collection=res.icons||[];state.all=state.collection.map(n=>prefix+':'+n).filter(k=>!!splitKey(k));state.total=state.all.length;state.mode='collection';state.searchTotal=state.total;updateViewInfo();renderPage(true);if(res.offline&&!state.offline[prefix])refreshOffline();}
 catch(e){if(token!==state.requestId)return;state.collection=[];state.all=[];state.total=0;state.searchTotal=0;updateViewInfo();renderPage(true);message(e.message,'error')}
 finally{if(token===state.requestId)setLoading(false)}
}
function selectNav(nav){
 state.nav=nav;state.requestId++;state.mode='collection';state.search='';$('searchInput').value='';$('clearSearch').style.display='none';hideMessage();updateNav();renderSets();
 if(nav==='favorites'){state.all=Array.from(state.favorites).sort();state.total=state.all.length;state.searchTotal=state.total;updateViewInfo();renderPage(true)}
 else if(nav==='offline'){state.all=[];state.total=0;state.searchTotal=0;state.nav='offline';updateViewInfo();renderPage(true);$('iconGrid').innerHTML=`<div class="empty">${svgIcon('download')}<strong>Bibliotecas guardadas</strong>Selecciona una colección con el indicador verde en el panel izquierdo para utilizarla sin conexión.</div>`}
 else if(nav==='variants'){const token=state.requestId;state.all=[];state.total=0;state.searchTotal=0;state.mode='variants';state.variantOffset=0;setLoading(true);getJSON('/api/variants?start=0').then(res=>{if(token!==state.requestId)return;state.all=res.variants||[];state.total=res.total;state.searchTotal=res.total;updateViewInfo();renderPage(true)}).catch(e=>{if(token!==state.requestId)return;message(e.message,'error')}).finally(()=>{if(token===state.requestId)setLoading(false)})}
 else if(nav==='all'){const token=state.requestId;state.all=[];state.total=0;state.searchTotal=0;state.mode='browse';setLoading(true);getJSON('/api/browse?start=0').then(res=>{if(token!==state.requestId)return;state.all=res.icons||[];state.total=res.total;state.searchTotal=res.total;updateViewInfo();renderPage(true)}).catch(e=>{if(token!==state.requestId)return;message(e.message,'error')}).finally(()=>{if(token===state.requestId)setLoading(false)})}
}
function chooseIcon(key){if(!splitKey(key))return;state.selected=key;const [prefix,name]=splitKey(key);$('inspectName').textContent=name.replaceAll('-',' ');$('inspectPrefix').textContent=prefix+':'+name;$('previewImage').src=urlFor(key);applyVariantPreview();$('favActionLabel').textContent=state.favorites.has(key)?'Eliminar de favoritos':'Añadir a favoritos';redrawCards()}
function toggleFavorite(key=state.selected){if(!splitKey(key))return;if(state.favorites.has(key))state.favorites.delete(key);else state.favorites.add(key);updateFavoritesCount();saveState();if(state.nav==='favorites'){selectNav('favorites')}else{redrawCards()}notify(state.favorites.has(key)?'Añadido a favoritos':'Eliminado de favoritos')}
async function executeSearch(){
 const q=$('searchInput').value.trim();state.search=q;const token=++state.requestId;hideMessage();if(!q){if(state.nav==='collection')selectCollection(state.prefix);else selectNav(state.nav);return}
 $('clearSearch').style.display='block';const prefix=state.nav==='collection'?state.prefix:'';state.mode='search';setLoading(true);
 if(state.nav==='favorites'){state.all=Array.from(state.favorites).filter(k=>k.toLowerCase().includes(q.toLowerCase()));state.total=state.all.length;state.searchTotal=state.total;updateViewInfo();renderPage(true);setLoading(false);return}
 if(state.nav==='collection'&&state.collection.length){state.all=state.collection.filter(n=>n.toLowerCase().includes(q.toLowerCase())).map(n=>state.prefix+':'+n);state.total=state.all.length;state.searchTotal=state.total;updateViewInfo();renderPage(true);setLoading(false);return}
 if(q.length<2){state.all=[];state.searchTotal=0;updateViewInfo();renderPage(true);setLoading(false);return}
 try{const result=await getJSON('/api/search?query='+encodeURIComponent(q)+'&start=0'+(prefix?'&prefix='+encodeURIComponent(prefix):''));if(state.requestId!==token)return;state.all=(result.icons||[]).filter(k=>!!splitKey(k));state.total=state.all.length;state.searchTotal=Number(result.total||state.all.length);state.globalStart=state.all.length;updateViewInfo();renderPage(true);if(result.offline)message('Resultados limitados a las colecciones guardadas: sin conexión.');}
 catch(e){if(state.requestId!==token)return;state.all=[];state.searchTotal=0;updateViewInfo();renderPage(true);message(e.message,'error')}
 finally{if(state.requestId===token)setLoading(false)}
}
async function loadMore(){if(state.page*state.pageSize<state.all.length){renderPage(false);return}
 if(state.mode==='variants'&&state.variantOffset+state.all.length<state.searchTotal){const token=state.requestId;setLoading(true);try{const x=await getJSON('/api/variants?start='+(state.variantOffset+state.all.length));if(token!==state.requestId)return;const extra=x.variants||[];if(!extra.length){$('loadMore').classList.add('hidden');return}state.all.push(...extra);renderPage(false)}catch(e){notify(e.message)}finally{setLoading(false)}return}
 if(state.mode==='browse' && state.all.length<state.searchTotal){const token=state.requestId;setLoading(true);try{const x=await getJSON('/api/browse?start='+state.all.length);if(token!==state.requestId)return;state.all.push(...(x.icons||[]));renderPage(false)}catch(e){notify(e.message)}finally{setLoading(false)}return}
 if(state.mode!=='search'||state.all.length>=state.searchTotal)return;
 const token=state.requestId;const prefix=state.nav==='collection'?state.prefix:'';
 setLoading(true);try{const q=state.search;const result=await getJSON('/api/search?query='+encodeURIComponent(q)+'&start='+state.globalStart+(prefix?'&prefix='+encodeURIComponent(prefix):''));if(token!==state.requestId)return;
 const extra=(result.icons||[]).filter(k=>!!splitKey(k));if(!extra.length){$('loadMore').classList.add('hidden');return}
 state.all.push(...extra);state.globalStart+=extra.length;renderPage(false)}catch(e){message(e.message,'error')}finally{setLoading(false)}
}
async function savePack(prefix){if(!simpleKey(prefix)||prefix==='hashcod')return false;
 try{const res=await getJSON('/api/pack?prefix='+encodeURIComponent(prefix),{method:'POST'});notify(`Colección ${prefix} guardada · ${nice(res.total)} iconos`);await refreshOffline();if(state.prefix===prefix&&state.nav==='collection')await selectCollection(prefix);return true}catch(e){message(`${prefix}: ${e.message}`,'error');return false}}
async function saveEssentials(){const b=$('saveEssentials');const packs=['lucide','tabler','ph','iconoir','material-symbols'];b.disabled=true;let ok=0;for(let i=0;i<packs.length;i++){b.textContent=`Guardando ${i+1}/5 · ${packs[i]}…`;if(await savePack(packs[i]))ok++}b.disabled=false;b.innerHTML=svgIcon('download')+' Guardar 5 colecciones';notify(`Descarga de bibliotecas: ${ok} de 5 completas`)}
function applyVariantPreview(){
  if(!$('previewImage'))return;
  $('previewImage').style.transform='rotate('+state.rotation+'deg)';
  $('previewImage').parentElement.style.backgroundColor=state.background==='transparent'?'transparent':state.background;
  document.querySelectorAll('.icon-card:not(.variant-card) .icon-thumb img').forEach(el=>el.style.transform='rotate('+state.rotation+'deg)');
}
function styleExportSVG(svg){
  if(state.rotation===0&&state.background==='transparent')return svg;
  const doc=new DOMParser().parseFromString(svg,'image/svg+xml');
  if(doc.querySelector('parsererror'))throw Error('SVG no válido para personalizar');
  const root=doc.documentElement;if(root.localName!=='svg')throw Error('SVG no reconocido');
  const vb=(root.getAttribute('viewBox')||'0 0 24 24').split(/[ ,]+/).map(Number);
  if(vb.length!==4||!vb.every(Number.isFinite))throw Error('Dimensiones SVG no válidas');
  const [left,top,width,height]=vb;
  if(state.rotation){
    const group=doc.createElementNS('http://www.w3.org/2000/svg','g');
    group.setAttribute('transform',`rotate(${state.rotation} ${left+width/2} ${top+height/2})`);
    while(root.firstChild)group.appendChild(root.firstChild);
    root.appendChild(group);
  }
  if(state.background!=='transparent'){
    const rect=doc.createElementNS('http://www.w3.org/2000/svg','rect');
    rect.setAttribute('x',left);rect.setAttribute('y',top);rect.setAttribute('width',width);rect.setAttribute('height',height);rect.setAttribute('fill',state.background);
    root.insertBefore(rect,root.firstChild);
  }
  return new XMLSerializer().serializeToString(root);
}
async function readSVG(key=state.selected){
 if(!splitKey(key))throw Error('Selecciona un icono');const res=await fetch(urlFor(key));
 if(!res.ok)throw Error('No se encontró este icono en la biblioteca local.');
 let svg=await res.text();if(!svg.includes('<svg'))throw Error('Formato SVG inválido');return styleExportSVG(svg)
}
function downloadBlob(data,filename,mime){const blob=data instanceof Blob?data:new Blob([data],{type:mime});const u=URL.createObjectURL(blob);const a=document.createElement('a');a.href=u;a.download=filename;a.click();setTimeout(()=>URL.revokeObjectURL(u),4500)}
function filename(ext){return state.selected.replace(':','-').replace(/[^a-z0-9_-]/g,'_')+'.'+ext}
async function downloadSVG(){try{const svg=await readSVG();downloadBlob(svg,filename('svg'),'image/svg+xml');notify('SVG descargado')}catch(e){notify(e.message)}}
async function copySVG(){try{const svg=await readSVG();await navigator.clipboard.writeText(svg);notify('SVG copiado al portapapeles')}catch(e){notify('No se pudo copiar: '+e.message)}}
async function copyJSX(){try{const svg=await readSVG();const jsx=svg.replace(/\bclass=/g,'className=').replace(/stroke-width=/g,'strokeWidth=').replace(/stroke-linecap=/g,'strokeLinecap=').replace(/stroke-linejoin=/g,'strokeLinejoin=').replace(/fill-rule=/g,'fillRule=').replace(/clip-rule=/g,'clipRule=').replace(/stroke-miterlimit=/g,'strokeMiterlimit=').replace(/stroke-dasharray=/g,'strokeDasharray=').replace(/stroke-dashoffset=/g,'strokeDashoffset=').replace(/clip-path=/g,'clipPath=').replace(/fill-opacity=/g,'fillOpacity=').replace(/stroke-opacity=/g,'strokeOpacity=').replace(/xlink:href=/g,'xlinkHref=').replace(/style="color:([^"]+)"/g,(_,color)=>`style={{ color: '${color}' }}`).replace('<svg ','<svg {...props} ');await navigator.clipboard.writeText('export function OpenIcon(props) {\n  return (\n    '+jsx+'\n  );\n}');notify('Componente React JSX copiado')}catch(e){notify('No se pudo copiar: '+e.message)}}
async function createPNGBlob(key=state.selected,size=Number($('exportSize').value)||512){
  const svg=await readSVG(key);
  const source=new Blob([svg],{type:'image/svg+xml'});
  const src=URL.createObjectURL(source);
  try{
    const image=await new Promise((resolve,reject)=>{
      const img=new Image();img.onload=()=>resolve(img);
      img.onerror=()=>reject(new Error('Este SVG no se puede convertir en PNG'));
      img.src=src;
    });
    const canvas=document.createElement('canvas');canvas.width=size;canvas.height=size;
    const ctx=canvas.getContext('2d');if(!ctx)throw new Error('Canvas 2D no disponible');
    ctx.clearRect(0,0,size,size);
    ctx.drawImage(image,0,0,size,size);
    return await new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(new Error('No se pudo producir el PNG')),'image/png'));
  }finally{URL.revokeObjectURL(src)}
}
async function downloadPNG(){
 try{const png=await createPNGBlob();downloadBlob(png,filename('png'),'image/png');notify('PNG descargado')}
 catch(e){notify('No se pudo exportar: '+e.message)}
}
async function copyPNG(){
 if(!state.selected){notify('Selecciona un icono');return}
 try{
   // ClipboardItem promises allow conversion to finish after the click without losing user activation.
   const blobPromise=createPNGBlob();
   if(navigator.clipboard?.write && typeof ClipboardItem!=='undefined'){
      try{await navigator.clipboard.write([new ClipboardItem({'image/png':blobPromise})]);notify('PNG copiado · Pega con Ctrl+V');return}catch(err){console.warn('Web clipboard failed; trying native Windows clipboard',err)}
   }
   // Fallback uses Win32 clipboard APIs from the local EXE, not an external website.
   const png=await blobPromise;
   const req=await fetch('/api/clipboard/png',{method:'POST',headers:{'Content-Type':'image/png'},body:png});
   if(!req.ok)throw Error('El portapapeles no está disponible. Usa Descargar PNG o abre la aplicación en Edge/Chrome.');
   notify('PNG copiado al portapapeles de Windows · Ctrl+V');
 }catch(e){notify('No se pudo copiar PNG: '+e.message)}
}

async function importJSON(file){if(!file)return;if(file.size>60*1024*1024){notify('El archivo excede 60 MB');return}const bytes=await file.arrayBuffer();try{const data=await getJSON('/api/import',{method:'POST',headers:{'Content-Type':'application/json'},body:bytes});notify(`Importados ${nice(data.total)} iconos de ${data.prefix}`);await refreshOffline();state.collections[data.prefix]??={name:data.prefix,total:data.total};renderSets();await selectCollection(data.prefix)}catch(e){message('Error al importar: '+e.message,'error')}}
function openModal(){$('modal').classList.remove('hidden')}
function bind(){
 document.querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click',()=>selectNav(b.dataset.nav)));
 $('setFilter').addEventListener('input',renderSets);
 $('searchInput').addEventListener('input',()=>{clearTimeout(searchTimer);searchTimer=setTimeout(executeSearch,280)});
 $('searchInput').addEventListener('keydown',e=>{if(e.key==='Enter'){clearTimeout(searchTimer);executeSearch()}});
 $('clearSearch').addEventListener('click',()=>{$('searchInput').value='';executeSearch()});
 $('colorPicker').addEventListener('input',e=>{state.color=e.target.value;document.documentElement.style.setProperty('--icon-tone',state.color);saveState();redrawCards();syncColorControls()});
 $('paletteSelect').addEventListener('change',e=>{state.color=e.target.value;$('colorPicker').value=state.color;saveState();redrawCards();syncColorControls()});
 $('rotationSelect').addEventListener('change',e=>{state.rotation=Number(e.target.value);saveState();applyVariantPreview()});
 $('backgroundSelect').addEventListener('change',e=>{state.background=e.target.value;saveState();applyVariantPreview();syncColorControls()});
 $('sizeSelect').addEventListener('change',e=>{document.querySelectorAll('.icon-thumb img').forEach(img=>{img.style.width=e.target.value+'px';img.style.height=e.target.value+'px'})});
 $('themeBtn').addEventListener('click',()=>{state.theme=state.theme==='dark'?'light':'dark';document.documentElement.classList.toggle('light',state.theme==='light');saveState()});
 $('variantGo').addEventListener('click',jumpToVariant);$('variantJump').addEventListener('keydown',e=>{if(e.key==='Enter')jumpToVariant()});$('saveSet').addEventListener('click',()=>savePack(state.prefix));$('saveEssentials').addEventListener('click',()=>$('fileImport').click());$('installAll').addEventListener('click',startBulkInstall);bindColorStudio();
 $('loadMore').addEventListener('click',loadMore);
 $('inspectorClose').addEventListener('click',()=>{state.selected='';$('inspectName').textContent='Selecciona un icono';$('inspectPrefix').textContent='—';$('previewImage').removeAttribute('src');redrawCards()});
 $('downloadSvg').addEventListener('click',downloadSVG);$('copySvg').addEventListener('click',copySVG);$('copyJSX').addEventListener('click',copyJSX);$('downloadPng').addEventListener('click',downloadPNG);$('copyPng').addEventListener('click',copyPNG);$('toggleFav').addEventListener('click',()=>toggleFavorite());
 $('importBtn').addEventListener('click',()=>$('fileImport').click());$('fileImport').addEventListener('change',async e=>{await importJSON(e.target.files?.[0]);e.target.value=''});
 $('aboutBtn').addEventListener('click',openModal);$('licensesBtn').addEventListener('click',openModal);$('modalClose').addEventListener('click',()=>$('modal').classList.add('hidden'));$('modal').addEventListener('click',e=>{if(e.target===$('modal'))$('modal').classList.add('hidden')});
 $('exitBtn').addEventListener('click',async()=>{if(confirm('¿Cerrar Openicons by Hashcod?')){await fetch('/api/quit',{method:'POST'}).catch(()=>{});window.close()}});
 $('refreshSets').addEventListener('click',refreshCatalog);
 document.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('searchInput').focus();$('searchInput').select()}if(e.key==='Escape'){$('modal').classList.add('hidden');$('searchInput').blur()}});
 window.addEventListener('online',refreshCatalog);
}

// Infinite lazy variant gallery: 400 actual SVG export configurations per base icon.
function addVariantItems(items){
 const fragment=document.createDocumentFragment();
 for(const v of items){if(!v||!splitKey(v.key))continue;
  const [prefix,name]=splitKey(v.key);
  const card=document.createElement('article');card.className='icon-card variant-card';
  card.innerHTML=`<div class="icon-thumb" role="button" tabindex="0" aria-label="Aplicar variante ${esc(name)}"><img loading="lazy" decoding="async" alt="${esc(name)}" src="${esc('/api/icon?prefix='+encodeURIComponent(prefix)+'&name='+encodeURIComponent(name)+'&color='+encodeURIComponent(v.color))}"/></div><div class="card-name">${esc(name.replaceAll('-',' '))}</div><div class="card-prefix">#${v.variant+1} · ${esc(v.color)} · ${v.rotation}°</div>`;
  card.dataset.key=v.key;const thumb=card.querySelector('.icon-thumb');thumb.style.backgroundColor=v.background==='transparent'?'var(--thumb)':v.background;
  const img=thumb.querySelector('img');img.style.transform=`rotate(${v.rotation}deg)`;
  const activate=()=>{state.color=v.color;state.rotation=v.rotation;state.background=v.background;$('rotationSelect').value=String(v.rotation);selectValueOrCustom('backgroundSelect',v.background);selectValueOrCustom('paletteSelect',v.color);$('colorPicker').value=v.color;saveState();syncColorControls();chooseIcon(v.key);notify('Variante aplicada y lista para exportar')};
  thumb.addEventListener('click',activate);thumb.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();activate()}});
  fragment.appendChild(card);
 }
 $('iconGrid').appendChild(fragment);
}

// One-click installation inside the app: no browser or manual npm commands.
let installPolling=null;
async function loadInstallStatus(){
 try{
  const st=await getJSON('/api/install/status');const button=$('installAll'),bar=$('installProgress');
  button.disabled=!!st.running;
  bar.classList.toggle('hidden',!st.running&&st.total===0);
  bar.value=st.total?Math.round(100*st.finished/st.total):0;
  $('installStatus').textContent=st.running?`Instalando: ${nice(st.finished)} / ${nice(st.total||0)} colecciones · ${nice(st.installed)} nuevas · ${nice(st.failed)} fallidas`:
    st.total?`Proceso finalizado: ${nice(st.installed)} nuevas, ${nice(st.skipped)} existentes, ${nice(st.failed)} fallidas.${st.lastError?' Detalle: '+st.lastError:''}`:
    st.lastError?'Instalación no completada: '+st.lastError:'Las colecciones adicionales no están instaladas. Pulsa Instalar catálogo completo para incorporarlas.';
  if(st.running){if(!installPolling)installPolling=setInterval(loadInstallStatus,1600)}
  else if(installPolling){clearInterval(installPolling);installPolling=null;await refreshOffline();await refreshCatalog();if(state.nav==='all'||state.nav==='variants')selectNav(state.nav)}
 }catch(e){$('installStatus').textContent=e.message}
}
async function jumpToVariant(){
 if(state.mode!=='variants')return;
 const value=Number($('variantJump').value);
 if(!Number.isSafeInteger(value)||value<1||value>state.searchTotal){notify('Indica un número válido de 1 a '+nice(state.searchTotal));return}
 const token=++state.requestId;setLoading(true);
 try{const x=await getJSON('/api/variants?start='+(value-1));if(token!==state.requestId)return;
   state.variantOffset=value-1;state.all=x.variants||[];state.total=x.total;state.searchTotal=x.total;
   updateViewInfo();renderPage(true);notify('Mostrando desde la combinación '+nice(value));
 }catch(e){notify(e.message)}finally{if(token===state.requestId)setLoading(false)}
}
async function startBulkInstall(){
 const button=$('installAll');button.disabled=true;
 try{await getJSON('/api/install/start',{method:'POST'});notify('Instalando el catálogo oficial dentro de Openicons…');await loadInstallStatus()}
 catch(e){notify('No se pudo iniciar: '+e.message);button.disabled=false}
}

/* Adaptación del componente ColorPalette de jal-co/ui (Justin Levine, MIT).
   Añade edición real de iconos y fondos, con HEX, RGB, copia y cuentagotas. */
const swatchColors=[
 ['Grafito','#17191d'],['Blanco','#f8fafc'],['Esmeralda','#00b894'],['Azul','#3b82f6'],
 ['Violeta','#a855f7'],['Rosa','#f43f5e'],['Ámbar','#f59e0b'],['Rojo','#ef4444'],
 ['Cian','#06b6d4'],['Pizarra','#64748b']
];
const swatchBackgrounds=[['Blanco','#ffffff'],['Negro','#121212'],['Menta','#a0e2c5'],['Celeste','#dbeafe'],['Lavanda','#ede9fe'],['Crema','#fef3c7'],['Rosa suave','#ffe4e6'],['Gris claro','#e2e8f0'],['Pizarra','#1e293b']];
const clampChannel=x=>Math.max(0,Math.min(255,Math.round(Number(x)||0)));
const colorToRGB=c=>[1,3,5].map(i=>parseInt(c.slice(i,i+2),16));
const rgbToColor=(r,g,b)=>'#'+[r,g,b].map(n=>clampChannel(n).toString(16).padStart(2,'0')).join('');
function currentStudioValue(){const bg=state.paletteTarget==='background';return bg?(state.background==='transparent'?'#ffffff':state.background):state.color}
function applyStudioColor(value){if(!/^#[0-9a-f]{6}$/i.test(value))return;
 value=value.toLowerCase();
 if(state.paletteTarget==='background'){state.background=value;const sel=$('backgroundSelect');let opt=sel.querySelector('option[data-custom]');if(![...sel.options].some(x=>x.value===value)){if(!opt){opt=document.createElement('option');opt.dataset.custom='true';sel.appendChild(opt)}opt.value=value;opt.textContent='Personalizado '+value;}sel.value=value;}
 else{state.color=value;$('colorPicker').value=value;const sel=$('paletteSelect');let opt=sel.querySelector('option[data-custom]');if(![...sel.options].some(x=>x.value===value)){if(!opt){opt=document.createElement('option');opt.dataset.custom='true';sel.appendChild(opt)}opt.value=value;opt.textContent='Personalizado '+value;}sel.value=value;}
 saveState();redrawCards();syncColorControls();
}
function paintJalcoPalette(){
 const container=$('jalcoPalette'),colors=state.paletteTarget==='background'?swatchBackgrounds:swatchColors;
 container.replaceChildren();
 for(const [name,value] of colors){
  const el=document.createElement('button');el.type='button';el.className='jalco-swatch'+(currentStudioValue().toLowerCase()===value?' chosen':'');
  el.setAttribute('data-slot','color-swatch');el.setAttribute('aria-label',`Aplicar ${name}: ${value}`);el.title=`Aplicar ${name} · ${value}`;
  const paint=document.createElement('span');paint.className='jalco-swatch-paint';paint.style.backgroundColor=value;
  const description=document.createElement('span');description.className='jalco-swatch-details';
  const nameEl=document.createElement('strong');nameEl.textContent=name;
  const valueEl=document.createElement('small');valueEl.textContent=value;
  description.append(nameEl,valueEl);el.append(paint,description);el.addEventListener('click',()=>applyStudioColor(value));
  container.appendChild(el);
 }
}
function syncColorControls(){if(!$('studioHex'))return;
 const hex=currentStudioValue(),rgb=colorToRGB(hex);
 $('studioHex').value=hex;$('studioHex').classList.remove('invalid');$('studioColorPicker').value=hex;
 for(let i=0;i<3;i++){const key=['R','G','B'][i];$('studio'+key).value=rgb[i];$('studio'+key+'Out').textContent=String(rgb[i]);}
 $('colorReadout').textContent=`rgb(${rgb.join(', ')})`;
 $('paletteForeground').classList.toggle('selected',state.paletteTarget==='icon');$('paletteForeground').setAttribute('aria-pressed',String(state.paletteTarget==='icon'));
 $('paletteBackground').classList.toggle('selected',state.paletteTarget==='background');$('paletteBackground').setAttribute('aria-pressed',String(state.paletteTarget==='background'));
 $('transparentBg').classList.toggle('selected',state.background==='transparent');paintJalcoPalette();
}
async function copyText(value){if(navigator.clipboard?.writeText)try{await navigator.clipboard.writeText(value);return true}catch{}
 const textarea=document.createElement('textarea');textarea.value=value;textarea.style.position='fixed';textarea.style.opacity='0';document.body.appendChild(textarea);textarea.select();
 const ok=document.execCommand('copy');textarea.remove();return ok;
}
function bindColorStudio(){
 $('paletteForeground').addEventListener('click',()=>{state.paletteTarget='icon';syncColorControls()});
 $('paletteBackground').addEventListener('click',()=>{state.paletteTarget='background';syncColorControls()});
 $('studioColorPicker').addEventListener('input',e=>applyStudioColor(e.target.value));
 $('studioHex').addEventListener('input',e=>{const h=e.target.value.trim();if(/^#[0-9a-f]{6}$/i.test(h))applyStudioColor(h);else e.target.classList.add('invalid')});
 for(const key of ['R','G','B'])$('studio'+key).addEventListener('input',()=>applyStudioColor(rgbToColor(...['R','G','B'].map(x=>$('studio'+x).value))));
 $('copyColorValue').addEventListener('click',async()=>notify(await copyText(currentStudioValue())?'Color HEX copiado':'No se pudo copiar el color'));
 $('transparentBg').addEventListener('click',()=>{state.background='transparent';$('backgroundSelect').value='transparent';state.paletteTarget='background';saveState();redrawCards();syncColorControls()});
 $('pickScreenColor').addEventListener('click',async()=>{if(!window.EyeDropper){notify('El cuentagotas no está disponible en este navegador');return}try{const result=await new EyeDropper().open();applyStudioColor(result.sRGBHex)}catch{notify('Cuentagotas cancelado')}});
}

async function init(){bind();await loadState();await refreshOffline();await selectCollection('mdi');refreshCatalog();await loadInstallStatus();if(state.all.length)chooseIcon(state.all[0]);setInterval(()=>fetch('/api/ping').catch(()=>{}),20000)}
init();
