//go:build !windows

package main

import "errors"

func initializeWindowsIdentity() {}
func writePNGClipboard(data []byte) error {
	return errors.New("este portapapeles nativo requiere Windows")
}
