// Openicons by Hashcod — independent desktop icon browser for Iconify collections.
// Copyright (c) 2026 Hashcod. Source code licensed MIT (see LICENSE).
package main

import (
	"bytes"
	"compress/gzip"
	"context"
	"embed"
	"encoding/json"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

//go:embed web/* data/index.json data/names.json.gz data/packs/*
var assets embed.FS

var validKey = regexp.MustCompile(`^[a-z0-9][a-z0-9_-]{0,99}$`)
var validHex = regexp.MustCompile(`^#[0-9a-fA-F]{6}$`)
var apiBase = "https://api.iconify.design"
var cdnBase = "https://cdn.jsdelivr.net/npm/@iconify-json"
var downloadGate = make(chan struct{}, 8)

const maxPack = 60 << 20

// This manifest is generated from upstream IconifyJSON packages during build time.
// Every packaged icon is available without a network request or extra installation.
var bundledPrefixes []string
var bundledInfo map[string]json.RawMessage
var embeddedNames map[string][]string
var embeddedNamesOnce sync.Once
var embeddedNamesErr error

func init() {
	raw, err := assets.ReadFile("data/index.json")
	if err != nil {
		panic("missing bundled icon index: " + err.Error())
	}
	var index struct {
		Collections map[string]json.RawMessage `json:"collections"`
	}
	if err = json.Unmarshal(raw, &index); err != nil || len(index.Collections) == 0 {
		panic("invalid bundled icon index")
	}
	bundledInfo = index.Collections
	for p := range bundledInfo {
		bundledPrefixes = append(bundledPrefixes, p)
	}
	sort.Strings(bundledPrefixes)
}

func readCompressedAsset(name string, max int64) ([]byte, error) {
	b, err := assets.ReadFile(name)
	if err != nil {
		return nil, err
	}
	gz, err := gzip.NewReader(bytes.NewReader(b))
	if err != nil {
		return nil, err
	}
	defer gz.Close()
	out, err := io.ReadAll(io.LimitReader(gz, max+1))
	if err != nil {
		return nil, err
	}
	if int64(len(out)) > max {
		return nil, errors.New("embedded icon collection is too large")
	}
	return out, nil
}
func bundledSearchIndex() (map[string][]string, error) {
	embeddedNamesOnce.Do(func() {
		b, err := readCompressedAsset("data/names.json.gz", 60<<20)
		if err != nil {
			embeddedNamesErr = err
			return
		}
		embeddedNamesErr = json.Unmarshal(b, &embeddedNames)
	})
	return embeddedNames, embeddedNamesErr
}
func bundleTotal(prefix string) int {
	var entry struct {
		Total int `json:"total"`
	}
	json.Unmarshal(bundledInfo[prefix], &entry)
	return entry.Total
}

func mergeBundledCatalog(b []byte) ([]byte, error) {
	var obj map[string]json.RawMessage
	if err := json.Unmarshal(b, &obj); err != nil {
		return nil, err
	}
	if obj == nil {
		obj = map[string]json.RawMessage{}
	}
	for k, v := range bundledInfo {
		obj[k] = v
	}
	return json.Marshal(obj)
}

const maxAPI = 12 << 20

var httpClient = &http.Client{Timeout: 22 * time.Second, CheckRedirect: func(req *http.Request, via []*http.Request) error {
	if len(via) > 5 {
		return errors.New("demasiadas redirecciones")
	}
	if req.URL.Scheme != "https" {
		return errors.New("solo HTTPS")
	}
	return nil
}}

type iconDef struct {
	Body   string `json:"body"`
	Width  int    `json:"width"`
	Height int    `json:"height"`
	Left   int    `json:"left"`
	Top    int    `json:"top"`
	HFlip  bool   `json:"hFlip"`
	VFlip  bool   `json:"vFlip"`
	Rotate int    `json:"rotate"`
	Parent string `json:"parent"`
}
type iconSet struct {
	Prefix  string             `json:"prefix"`
	Width   int                `json:"width"`
	Height  int                `json:"height"`
	Icons   map[string]iconDef `json:"icons"`
	Aliases map[string]iconDef `json:"aliases"`
	Info    json.RawMessage    `json:"info,omitempty"`
}
type application struct {
	dir         string
	mu          sync.RWMutex
	packCache   map[string]*iconSet
	activeMu    sync.Mutex
	lastActive  time.Time
	installerMu sync.Mutex
	installer   installProgress
}

func newApp(dir string) *application {
	return &application{dir: dir, packCache: map[string]*iconSet{}, lastActive: time.Now()}
}
func (a *application) touch() { a.activeMu.Lock(); a.lastActive = time.Now(); a.activeMu.Unlock() }
func (a *application) expired() bool {
	a.activeMu.Lock()
	defer a.activeMu.Unlock()
	return time.Since(a.lastActive) > 115*time.Second
}
func isKey(s string) bool { return validKey.MatchString(s) }
func getJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	json.NewEncoder(w).Encode(v)
}
func errJSON(w http.ResponseWriter, msg string, code int) {
	w.WriteHeader(code)
	getJSON(w, map[string]any{"error": msg})
}
func (a *application) folder(name string) string { return filepath.Join(a.dir, name) }
func (a *application) file(folder, key string) string {
	return filepath.Join(a.folder(folder), key+".json")
}

func fetchRemote(ctx context.Context, addr string, limit int64) ([]byte, error) {
	// Only call with trusted URLs assembled by the application.
	select {
	case downloadGate <- struct{}{}:
		defer func() { <-downloadGate }()
	case <-ctx.Done():
		return nil, ctx.Err()
	}
	req, err := http.NewRequestWithContext(ctx, "GET", addr, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "Openicons-by-Hashcod/2.0 (+https://iconify.design/)")
	resp, err := httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("servidor remoto HTTP %d", resp.StatusCode)
	}
	if resp.ContentLength > limit {
		return nil, errors.New("respuesta demasiado grande")
	}
	b, err := io.ReadAll(io.LimitReader(resp.Body, limit+1))
	if err != nil {
		return nil, err
	}
	if int64(len(b)) > limit {
		return nil, errors.New("respuesta demasiado grande")
	}
	return b, nil
}
func atomicWrite(path string, b []byte) error {
	if err := os.MkdirAll(filepath.Dir(path), 0700); err != nil {
		return err
	}
	temp, err := os.CreateTemp(filepath.Dir(path), ".openicons-*")
	if err != nil {
		return err
	}
	defer os.Remove(temp.Name())
	if _, err = temp.Write(b); err != nil {
		temp.Close()
		return err
	}
	if err = temp.Close(); err != nil {
		return err
	}
	return os.Rename(temp.Name(), path)
}
func loadStored(path string) ([]byte, error) { return os.ReadFile(path) }

// Catalogs and full-text searches are local-first and never require Iconify servers.
func (a *application) catalog(w http.ResponseWriter, r *http.Request) {
	catalog := make(map[string]json.RawMessage, len(bundledInfo)+200)
	for key, meta := range bundledInfo {
		catalog[key] = meta
	}
	for key, meta := range a.importedCatalog() {
		catalog[key] = meta
	}
	getJSON(w, catalog)
}
func getRawJSON(w http.ResponseWriter, b []byte) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	w.Write(b)
}

func validateSet(b []byte, prefix string) (*iconSet, error) {
	var set iconSet
	if err := json.Unmarshal(b, &set); err != nil {
		return nil, fmt.Errorf("JSON no válido: %w", err)
	}
	if !isKey(set.Prefix) {
		return nil, errors.New("prefijo de colección no válido")
	}
	if prefix != "" && prefix != set.Prefix {
		return nil, errors.New("la colección descargada tiene otro prefijo")
	}
	if len(set.Icons) == 0 {
		return nil, errors.New("colección sin iconos")
	}
	if len(set.Icons) > 200000 {
		return nil, errors.New("colección supera el límite de seguridad")
	}
	return &set, nil
}
func (a *application) getPack(prefix string) (*iconSet, error) {
	a.mu.RLock()
	found := a.packCache[prefix]
	a.mu.RUnlock()
	if found != nil {
		return found, nil
	}

	var b []byte
	var e error
	if _, builtin := bundledInfo[prefix]; builtin {
		b, e = readCompressedAsset("data/packs/"+prefix+".json.gz", maxPack)
	} else {
		b, e = loadStored(a.file("packs", prefix))
	}
	if e != nil {
		return nil, e
	}
	p, e := validateSet(b, prefix)
	if e != nil {
		return nil, e
	}
	a.mu.Lock()
	if existing := a.packCache[prefix]; existing != nil {
		p = existing
	} else {
		a.packCache[prefix] = p
	}
	a.mu.Unlock()
	return p, nil
}
func packNames(p *iconSet) []string {
	l := make([]string, 0, len(p.Icons)+len(p.Aliases))
	for k := range p.Icons {
		l = append(l, k)
	}
	for k := range p.Aliases {
		l = append(l, k)
	}
	sort.Strings(l)
	return l
}
func (a *application) collection(w http.ResponseWriter, r *http.Request) {
	prefix := r.URL.Query().Get("prefix")
	if !isKey(prefix) {
		errJSON(w, "Colección no válida", 400)
		return
	}
	if index, err := bundledSearchIndex(); err == nil {
		if names, ok := index[prefix]; ok {
			getJSON(w, map[string]any{"prefix": prefix, "icons": names, "total": len(names), "offline": true})
			return
		}
	}
	if names := a.namesFor(prefix); len(names) > 0 {
		getJSON(w, map[string]any{"prefix": prefix, "icons": names, "total": len(names), "offline": true})
		return
	}
	p := a.file("lists", prefix)
	if b, e := loadStored(p); e == nil {
		getRawJSON(w, b)
		return
	}
	b, e := fetchRemote(r.Context(), apiBase+"/collection?prefix="+url.QueryEscape(prefix), maxAPI)
	if e != nil {
		errJSON(w, "No hay conexión. Descarga esa colección para usarla sin internet.", 503)
		return
	}
	var src struct {
		Categories    map[string][]string `json:"categories"`
		Uncategorized []string            `json:"uncategorized"`
		Hidden        []string            `json:"hidden"`
		Icons         []string            `json:"icons"`
		Total         int                 `json:"total"`
	}
	if e := json.Unmarshal(b, &src); e != nil {
		errJSON(w, "Formato de colección desconocido", 502)
		return
	}
	seen := map[string]bool{}
	names := make([]string, 0, src.Total)
	add := func(s string) {
		if isKey(s) && !seen[s] {
			seen[s] = true
			names = append(names, s)
		}
	}
	for _, xs := range src.Categories {
		for _, n := range xs {
			add(n)
		}
	}
	for _, n := range src.Uncategorized {
		add(n)
	}
	for _, n := range src.Icons {
		add(n)
	}
	// Some collections contain icons only in hidden; keep them browsable too.
	for _, n := range src.Hidden {
		add(n)
	}
	if len(names) == 0 {
		errJSON(w, "La colección está vacía o no existe", 404)
		return
	}
	sort.Strings(names)
	raw, _ := json.Marshal(map[string]any{"prefix": prefix, "icons": names, "total": len(names), "offline": false})
	atomicWrite(p, raw)
	getRawJSON(w, raw)
}

func (a *application) search(w http.ResponseWriter, r *http.Request) {
	q := strings.ToLower(strings.TrimSpace(r.URL.Query().Get("query")))
	if len(q) < 2 || len(q) > 80 {
		errJSON(w, "Introduce al menos dos caracteres", 400)
		return
	}
	offset, _ := strconv.Atoi(r.URL.Query().Get("start"))
	if offset < 0 {
		offset = 0
	}
	if offset > 3000000 {
		offset = 3000000
	}
	prefix := r.URL.Query().Get("prefix")
	if prefix != "" && !isKey(prefix) {
		errJSON(w, "Colección no válida", 400)
		return
	}
	index, err := a.localNameIndex()
	if err != nil {
		errJSON(w, "Índice local dañado", 500)
		return
	}
	hits := make([]string, 0, 256)
	for p, names := range index {
		if prefix != "" && prefix != p {
			continue
		}
		for _, name := range names {
			if strings.Contains(name, q) {
				hits = append(hits, p+":"+name)
			}
		}
	}
	sort.Strings(hits)
	total := len(hits)
	if offset > total {
		offset = total
	}
	end := offset + 120
	if end > total {
		end = total
	}
	getJSON(w, map[string]any{"icons": hits[offset:end], "total": total, "start": offset, "limit": 120, "offline": true})
}
func (a *application) browse(w http.ResponseWriter, r *http.Request) {
	offset, _ := strconv.Atoi(r.URL.Query().Get("start"))
	if offset < 0 {
		offset = 0
	}
	if offset > 3000000 {
		offset = 3000000
	}
	index, err := a.localNameIndex()
	if err != nil {
		errJSON(w, "Índice local dañado", 500)
		return
	}
	icons, total := sortedIndexWindow(index, offset, 120)
	getJSON(w, map[string]any{"icons": icons, "total": total, "start": offset, "limit": 120, "offline": true})
}

func resolveIcon(set *iconSet, name string) (iconDef, bool) {
	if icon, ok := set.Icons[name]; ok {
		return icon, true
	}
	seen := map[string]bool{}
	chain := []iconDef{}
	cursor := name
	for i := 0; i < 16; i++ {
		if seen[cursor] {
			return iconDef{}, false
		}
		seen[cursor] = true
		a, found := set.Aliases[cursor]
		if !found {
			return iconDef{}, false
		}
		chain = append(chain, a)
		if root, found := set.Icons[a.Parent]; found {
			for j := len(chain) - 1; j >= 0; j-- {
				v := chain[j]
				if v.Width > 0 {
					root.Width = v.Width
				}
				if v.Height > 0 {
					root.Height = v.Height
				}
				root.HFlip = root.HFlip != v.HFlip
				root.VFlip = root.VFlip != v.VFlip
				root.Rotate = (root.Rotate + v.Rotate) % 4
			}
			return root, true
		}
		cursor = a.Parent
	}
	return iconDef{}, false
}

// Safe local <use href="#id"> is important for Iconify gradients, masks and symbols.
// Reject executable markup and every external reference. SVGs are never loaded from the web.
func validateSVGBody(body string) error {
	allowed := map[string]bool{}
	for _, tag := range []string{"svg", "g", "path", "rect", "circle", "ellipse", "line", "polyline", "polygon", "defs", "mask", "clippath", "lineargradient", "radialgradient", "stop", "filter", "fegaussianblur", "feoffset", "femerge", "femergenode", "fecolormatrix", "fecomposite", "feflood", "feblend", "fecomponenttransfer", "fefunca", "fefuncr", "fefuncg", "fefuncb", "feturbulence", "fedisplacementmap", "fedropshadow", "femorphology", "feimage", "fetc", "use", "pattern", "text", "tspan", "symbol", "marker", "title", "desc"} {
		allowed[tag] = true
	}
	lower := strings.ToLower(body)
	if strings.Contains(lower, "<!doctype") || strings.Contains(lower, "<!entity") || strings.Contains(lower, "<?") {
		return errors.New("entidades o instrucciones SVG prohibidas")
	}
	parser := xml.NewDecoder(strings.NewReader("<svg>" + body + "</svg>"))
	for {
		token, err := parser.Token()
		if errors.Is(err, io.EOF) {
			return nil
		}
		if err != nil {
			return fmt.Errorf("SVG mal formado: %w", err)
		}
		switch t := token.(type) {
		case xml.StartElement:
			if !allowed[strings.ToLower(t.Name.Local)] {
				return errors.New("etiqueta SVG prohibida: " + t.Name.Local)
			}
			for _, attr := range t.Attr {
				n := strings.ToLower(attr.Name.Local)
				v := strings.TrimSpace(attr.Value)
				l := strings.ToLower(v)
				if strings.HasPrefix(n, "on") {
					return errors.New("evento SVG no permitido")
				}
				if n == "xmlns" || attr.Name.Space == "xmlns" {
					if !strings.HasPrefix(l, "http://www.w3.org/") {
						return errors.New("espacio de nombres no permitido")
					}
					continue
				}
				if n == "href" {
					if !regexp.MustCompile(`^#[a-zA-Z_][a-zA-Z0-9_:.-]*$`).MatchString(v) {
						return errors.New("referencia externa no permitida")
					}
					continue
				}
				if strings.Contains(l, "javascript:") || strings.Contains(l, "data:") || strings.Contains(l, "http:") || strings.Contains(l, "https:") || strings.Contains(l, "file:") || strings.Contains(l, "@import") {
					return errors.New("recurso SVG externo o ejecutable")
				}
				rest := l
				for {
					start := strings.Index(rest, "url(")
					if start < 0 {
						break
					}
					rest = rest[start+4:]
					end := strings.Index(rest, ")")
					if end < 0 {
						return errors.New("url SVG mal formada")
					}
					ref := strings.Trim(strings.TrimSpace(rest[:end]), "\"'")
					if !strings.HasPrefix(ref, "#") {
						return errors.New("URL externa SVG")
					}
					rest = rest[end+1:]
				}
			}
		case xml.Directive, xml.ProcInst:
			return errors.New("contenido SVG activo prohibido")
		}
	}
}

func renderSVG(set *iconSet, name, color string) ([]byte, error) {
	icon, ok := resolveIcon(set, name)
	if !ok {
		return nil, errors.New("icono no encontrado")
	}
	if color == "" {
		color = "#16181e"
	}
	if !validHex.MatchString(color) {
		return nil, errors.New("color no válido")
	}
	if icon.Width <= 0 {
		icon.Width = set.Width
	}
	if icon.Height <= 0 {
		icon.Height = set.Height
	}
	if icon.Width <= 0 {
		icon.Width = 24
	}
	if icon.Height <= 0 {
		icon.Height = 24
	}
	if icon.Width > 4096 || icon.Height > 4096 {
		return nil, errors.New("dimensiones demasiado grandes")
	}
	if len(icon.Body) > 2<<20 {
		return nil, errors.New("icono demasiado grande")
	}
	if err := validateSVGBody(icon.Body); err != nil {
		return nil, err
	}
	body := icon.Body
	if icon.HFlip || icon.VFlip || icon.Rotate%4 != 0 {
		cx := float64(icon.Left) + float64(icon.Width)/2
		cy := float64(icon.Top) + float64(icon.Height)/2
		sx, sy := 1, 1
		if icon.HFlip {
			sx = -1
		}
		if icon.VFlip {
			sy = -1
		}
		body = fmt.Sprintf(`<g transform="translate(%g %g) rotate(%d) scale(%d %d) translate(%g %g)">%s</g>`, cx, cy, 90*(icon.Rotate%4), sx, sy, -cx, -cy, body)
	}
	out := fmt.Sprintf(`<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="%d %d %d %d" style="color:%s" aria-hidden="true">%s</svg>`, icon.Width, icon.Height, icon.Left, icon.Top, icon.Width, icon.Height, color, body)
	return []byte(out), nil
}
func (a *application) icon(w http.ResponseWriter, r *http.Request) {
	prefix := r.URL.Query().Get("prefix")
	name := r.URL.Query().Get("name")
	color := r.URL.Query().Get("color")
	if color == "" {
		color = "#17191d"
	}
	if !isKey(prefix) || !isKey(name) || !validHex.MatchString(color) {
		http.Error(w, "Solicitud inválida", 400)
		return
	}
	w.Header().Set("Content-Type", "image/svg+xml; charset=utf-8")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("Cache-Control", "private, max-age=3600")
	w.Header().Set("Content-Security-Policy", "default-src 'none'; style-src 'unsafe-inline'; sandbox")
	if set, e := a.getPack(prefix); e == nil {
		if b, e := renderSVG(set, name, color); e == nil {
			w.Write(b)
			return
		}
	}
	cache := filepath.Join(a.folder("svg"), prefix, name+".svg")
	if b, e := os.ReadFile(cache); e == nil {
		w.Write(bytes.ReplaceAll(b, []byte("currentColor"), []byte(color)))
		return
	}
	http.Error(w, "Icono no incluido en el catálogo local", 404)
}
func (a *application) pack(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		errJSON(w, "Método no permitido", 405)
		return
	}
	prefix := r.URL.Query().Get("prefix")
	if !isKey(prefix) || bundledInfo[prefix] != nil {
		errJSON(w, "Colección no válida", 400)
		return
	}
	if existing, e := a.getPack(prefix); e == nil {
		getJSON(w, map[string]any{"ok": true, "prefix": prefix, "total": len(existing.Icons) + len(existing.Aliases), "offline": true, "existing": true})
		return
	}
	urls := []string{cdnBase + "/" + url.PathEscape(prefix) + "/icons.json", "https://raw.githubusercontent.com/iconify/icon-sets/master/json/" + url.PathEscape(prefix) + ".json"}
	var last error
	for _, u := range urls {
		b, e := fetchRemote(r.Context(), u, maxPack)
		if e != nil {
			last = e
			continue
		}
		set, e := validateSet(b, prefix)
		if e != nil {
			last = e
			continue
		}
		if e = atomicWrite(a.file("packs", prefix), b); e != nil {
			errJSON(w, "No se pudo guardar el paquete: "+e.Error(), 500)
			return
		}
		a.mu.Lock()
		a.packCache[prefix] = set
		a.mu.Unlock()
		names := packNames(set)
		raw, _ := json.Marshal(map[string]any{"prefix": prefix, "icons": names, "total": len(names), "offline": true})
		atomicWrite(a.file("lists", prefix), raw)
		getJSON(w, map[string]any{"ok": true, "prefix": prefix, "total": len(names), "offline": true, "bytes": len(b)})
		return
	}
	errJSON(w, "No pude descargar el paquete: "+last.Error(), 502)
}
func (a *application) importPack(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		errJSON(w, "Método no permitido", 405)
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, maxPack)
	b, e := io.ReadAll(r.Body)
	if e != nil {
		errJSON(w, "El archivo supera el límite de 60 MB", 413)
		return
	}
	set, e := validateSet(b, "")
	if e != nil {
		errJSON(w, e.Error(), 400)
		return
	}
	if bundledInfo[set.Prefix] != nil {
		errJSON(w, "El catálogo integrado está reservado", 409)
		return
	}
	if e = atomicWrite(a.file("packs", set.Prefix), b); e != nil {
		errJSON(w, "No se pudo guardar", 500)
		return
	}
	a.mu.Lock()
	a.packCache[set.Prefix] = set
	a.mu.Unlock()
	names := packNames(set)
	raw, _ := json.Marshal(map[string]any{"prefix": set.Prefix, "icons": names, "total": len(names), "offline": true})
	atomicWrite(a.file("lists", set.Prefix), raw)
	getJSON(w, map[string]any{"ok": true, "prefix": set.Prefix, "total": len(names)})
}
func (a *application) offline(w http.ResponseWriter, r *http.Request) {
	offline := map[string]int{}
	for _, prefix := range bundledPrefixes {
		offline[prefix] = bundleTotal(prefix)
	}
	for _, prefix := range a.installedPrefixes() {
		if names := a.namesFor(prefix); len(names) > 0 {
			offline[prefix] = len(names)
		}
	}
	getJSON(w, map[string]any{"collections": offline, "cacheDir": a.dir})
}
func (a *application) statistics(w http.ResponseWriter, r *http.Request) {
	bundled := 0
	for _, prefix := range bundledPrefixes {
		bundled += bundleTotal(prefix)
	}
	installed := 0
	for _, prefix := range a.installedPrefixes() {
		installed += len(a.namesFor(prefix))
	}
	total := bundled + installed
	// completeOffline only means the CURRENTLY INSTALLED catalogue works offline.
	// This never claims that all of Iconify is included with the executable.
	getJSON(w, map[string]any{"distinctIcons": total, "bundledIcons": bundled, "downloadedIcons": installed,
		"variantsPerIcon": variantsPerIcon, "variantCombinations": int64(total) * variantsPerIcon,
		"completeOffline": true, "fullCatalogBundled": bundled >= 300000 && len(bundledPrefixes) >= 150})
}

type preferences struct {
	Favorites  []string `json:"favorites"`
	Theme      string   `json:"theme"`
	Color      string   `json:"color"`
	Rotation   int      `json:"rotation"`
	Background string   `json:"background"`
}

func (a *application) settings(w http.ResponseWriter, r *http.Request) {
	p := a.file("meta", "preferences")
	if r.Method == "GET" {
		b, e := os.ReadFile(p)
		if e != nil {
			getJSON(w, preferences{Favorites: []string{}, Theme: "dark", Color: "#17191d", Rotation: 0, Background: "transparent"})
			return
		}
		getRawJSON(w, b)
		return
	}
	if r.Method != "POST" {
		errJSON(w, "Método no permitido", 405)
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, 200<<10)
	var x preferences
	if err := json.NewDecoder(r.Body).Decode(&x); err != nil {
		errJSON(w, "Preferencias inválidas", 400)
		return
	}
	if x.Theme != "light" && x.Theme != "dark" {
		x.Theme = "dark"
	}
	if !validHex.MatchString(x.Color) {
		x.Color = "#17191d"
	}
	if x.Rotation != 0 && x.Rotation != 90 && x.Rotation != 180 && x.Rotation != 270 {
		x.Rotation = 0
	}
	if x.Background != "transparent" && !validHex.MatchString(x.Background) {
		x.Background = "transparent"
	}
	if len(x.Favorites) > 15000 {
		errJSON(w, "Demasiados favoritos", 400)
		return
	}
	result := make([]string, 0, len(x.Favorites))
	seen := map[string]bool{}
	for _, entry := range x.Favorites {
		parts := strings.Split(entry, ":")
		if len(parts) != 2 || !isKey(parts[0]) || !isKey(parts[1]) || seen[entry] {
			continue
		}
		seen[entry] = true
		result = append(result, entry)
	}
	x.Favorites = result
	b, _ := json.Marshal(x)
	if e := atomicWrite(p, b); e != nil {
		errJSON(w, "No se pudo guardar preferencias", 500)
		return
	}
	getJSON(w, map[string]bool{"ok": true})
}

func (a *application) clipboardPNG(w http.ResponseWriter, r *http.Request) {
	if r.Method != "POST" {
		errJSON(w, "Método no permitido", 405)
		return
	}
	r.Body = http.MaxBytesReader(w, r.Body, 10<<20)
	data, err := io.ReadAll(r.Body)
	if err != nil {
		errJSON(w, "PNG demasiado grande", 413)
		return
	}
	if len(data) < 8 || !bytes.Equal(data[:8], []byte{137, 80, 78, 71, 13, 10, 26, 10}) {
		errJSON(w, "PNG inválido", 400)
		return
	}
	if err := writePNGClipboard(data); err != nil {
		errJSON(w, err.Error(), 501)
		return
	}
	getJSON(w, map[string]bool{"ok": true})
}

func (a *application) routes() http.Handler {
	mux := http.NewServeMux()
	mux.HandleFunc("GET /", func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/" {
			http.NotFound(w, r)
			return
		}
		b, e := assets.ReadFile("web/index.html")
		if e != nil {
			http.Error(w, "Missing UI", 500)
			return
		}
		w.Header().Set("Content-Type", "text/html; charset=utf-8")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("Content-Security-Policy", "default-src 'self' data: blob:; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'")
		w.Write(b)
	})
	mux.HandleFunc("GET /app.css", func(w http.ResponseWriter, r *http.Request) {
		b, _ := assets.ReadFile("web/app.css")
		w.Header().Set("Content-Type", "text/css; charset=utf-8")
		w.Write(b)
	})
	mux.HandleFunc("GET /favicon.ico", func(w http.ResponseWriter, r *http.Request) {
		b, e := assets.ReadFile("web/favicon.ico")
		if e != nil {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "image/x-icon")
		w.Write(b)
	})
	mux.HandleFunc("GET /icon-192.png", func(w http.ResponseWriter, r *http.Request) {
		b, e := assets.ReadFile("web/icon-192.png")
		if e != nil {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "image/png")
		w.Write(b)
	})
	mux.HandleFunc("GET /icon-512.png", func(w http.ResponseWriter, r *http.Request) {
		b, e := assets.ReadFile("web/icon-512.png")
		if e != nil {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "image/png")
		w.Write(b)
	})
	mux.HandleFunc("GET /manifest.webmanifest", func(w http.ResponseWriter, r *http.Request) {
		b, e := assets.ReadFile("web/manifest.webmanifest")
		if e != nil {
			http.NotFound(w, r)
			return
		}
		w.Header().Set("Content-Type", "application/manifest+json")
		w.Write(b)
	})
	mux.HandleFunc("GET /app.js", func(w http.ResponseWriter, r *http.Request) {
		b, _ := assets.ReadFile("web/app.js")
		w.Header().Set("Content-Type", "application/javascript; charset=utf-8")
		w.Write(b)
	})
	mux.HandleFunc("GET /api/collections", a.catalog)
	mux.HandleFunc("GET /api/collection", a.collection)
	mux.HandleFunc("GET /api/search", a.search)
	mux.HandleFunc("GET /api/browse", a.browse)
	mux.HandleFunc("GET /api/icon", a.icon)
	mux.HandleFunc("POST /api/pack", a.pack)
	mux.HandleFunc("POST /api/import", a.importPack)
	mux.HandleFunc("GET /api/offline", a.offline)
	mux.HandleFunc("GET /api/statistics", a.statistics)
	mux.HandleFunc("GET /api/variants", a.variants)
	mux.HandleFunc("POST /api/install/start", a.installStart)
	mux.HandleFunc("GET /api/install/status", a.installStatus)
	mux.HandleFunc("POST /api/clipboard/png", a.clipboardPNG)
	mux.HandleFunc("GET /api/state", a.settings)
	mux.HandleFunc("POST /api/state", a.settings)
	mux.HandleFunc("GET /api/ping", func(w http.ResponseWriter, r *http.Request) { a.touch(); getJSON(w, map[string]bool{"ok": true}) })
	mux.HandleFunc("POST /api/quit", func(w http.ResponseWriter, r *http.Request) {
		getJSON(w, map[string]bool{"ok": true})
		go func() { time.Sleep(350 * time.Millisecond); os.Exit(0) }()
	})
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Browser requests are only trusted from loopback; enforce request origin for mutating operations.
		if r.Method == "POST" {
			o := r.Header.Get("Origin")
			if o != "" {
				parsed, e := url.Parse(o)
				if e != nil || parsed.Host != r.Host || parsed.Scheme != "http" {
					http.Error(w, "Origen no autorizado", 403)
					return
				}
			}
		}
		a.touch()
		mux.ServeHTTP(w, r)
	})
}
func appDataDir() string {
	if runtime.GOOS == "windows" {
		if dir := os.Getenv("LOCALAPPDATA"); dir != "" {
			return filepath.Join(dir, "Openicons by Hashcod")
		}
	}
	d, e := os.UserConfigDir()
	if e == nil {
		return filepath.Join(d, "Openicons by Hashcod")
	}
	return filepath.Join(os.TempDir(), "Openicons by Hashcod")
}
func openWindow(addr, dataDir string) {
	if runtime.GOOS == "windows" {
		edges := []string{}
		for _, base := range []string{os.Getenv("PROGRAMFILES(X86)"), os.Getenv("PROGRAMFILES"), os.Getenv("LOCALAPPDATA")} {
			if base == "" {
				continue
			}
			edges = append(edges, filepath.Join(base, "Microsoft", "Edge", "Application", "msedge.exe"))
			edges = append(edges, filepath.Join(base, "Google", "Chrome", "Application", "chrome.exe"))
		}
		for _, p := range edges {
			if info, e := os.Stat(p); e == nil && !info.IsDir() {
				c := exec.Command(p, "--app="+addr, "--new-window", "--window-size=1460,950", "--user-data-dir="+filepath.Join(dataDir, "browser-profile"))
				if c.Start() == nil {
					return
				}
			}
		}
		exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", addr).Start()
		return
	}
	// Linux/macOS local testing only
	var cmd *exec.Cmd
	if runtime.GOOS == "darwin" {
		cmd = exec.Command("open", addr)
	} else {
		cmd = exec.Command("xdg-open", addr)
	}
	cmd.Start()
}
func main() {
	initializeWindowsIdentity()
	dir := appDataDir()
	if e := os.MkdirAll(dir, 0700); e != nil {
		log.Fatal(e)
	}
	a := newApp(dir)
	ln, e := net.Listen("tcp4", "127.0.0.1:0")
	if e != nil {
		log.Fatal(e)
	}
	defer ln.Close()
	addr := "http://" + ln.Addr().String()
	srv := &http.Server{Handler: a.routes(), ReadHeaderTimeout: 10 * time.Second}
	go func() {
		if e := srv.Serve(ln); e != nil && !errors.Is(e, http.ErrServerClosed) {
			log.Printf("server error: %v", e)
		}
	}()
	go func() {
		ticker := time.NewTicker(25 * time.Second)
		defer ticker.Stop()
		for range ticker.C {
			if a.expired() {
				ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
				srv.Shutdown(ctx)
				cancel()
				os.Exit(0)
			}
		}
	}()
	fmt.Println("Openicons by Hashcod: " + addr)
	openWindow(addr, dir)
	select {}
}
