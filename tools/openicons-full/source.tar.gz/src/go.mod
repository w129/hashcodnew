module openicons.hashcod/local

go 1.23
