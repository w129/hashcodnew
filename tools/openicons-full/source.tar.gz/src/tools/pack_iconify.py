#!/usr/bin/env python3
"""Bundle IconifyJSON as gzip-compressed, independently licensed offline collections.

Input: JSON dir from https://github.com/iconify/icon-sets or npm @iconify/json.
The script never calls a network service. Supply --source to build the full catalog.
Run before compiling the Go application. Source data is not needed at runtime.
"""
import argparse
import gzip
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
VALID = re.compile(r"^[a-z0-9][a-z0-9_-]{0,99}$")


def valid_set(source: Path):
    obj = json.loads(source.read_text(encoding="utf-8"))
    prefix = obj.get("prefix")
    if not isinstance(prefix, str) or not VALID.fullmatch(prefix) or prefix != source.stem:
        raise ValueError("invalid or mismatched prefix")
    icons = obj.get("icons")
    if not isinstance(icons, dict) or not icons or len(icons) > 200000:
        raise ValueError("icon set is empty or exceeds safety limits")
    for name, val in icons.items():
        if not VALID.fullmatch(name) or not isinstance(val, dict) or not isinstance(val.get("body"), str):
            raise ValueError("invalid icon entry")
    aliases = obj.get("aliases", {})
    if not isinstance(aliases, dict) or any(not VALID.fullmatch(a) or not isinstance(v, dict) for a, v in aliases.items()):
        raise ValueError("invalid alias")
    return obj


def make_package(source_dirs: list[Path], output: Path, clean: bool = False, min_icons: int = 0):
    output.mkdir(parents=True, exist_ok=True)
    packs = output / "packs"
    packs.mkdir(exist_ok=True)
    if clean:
        for old in packs.glob("*.json.gz"):
            old.unlink()
    catalog = {}
    names = {}
    seen = set()
    skipped = []
    for src in source_dirs:
        if not src.is_dir():
            raise ValueError(f"source directory missing: {src}")
        for file in sorted(src.glob("*.json")):
            if file.stem in seen:
                continue
            try:
                item = valid_set(file)
                packed = json.dumps(item, ensure_ascii=False, separators=(",", ":")).encode()
                if len(packed) > 60 << 20:
                    raise ValueError("uncompressed collection exceeds 60 MiB")
            except (OSError, ValueError, json.JSONDecodeError, TypeError) as exc:
                skipped.append(f"{file.name}: {exc}")
                continue
            prefix = item["prefix"]
            seen.add(prefix)
            out = packs / f"{prefix}.json.gz"
            out.write_bytes(gzip.compress(packed, compresslevel=9, mtime=0))
            icons = sorted(set(item["icons"]) | set(item.get("aliases", {})))
            names[prefix] = icons
            metadata = item.get("info")
            if not isinstance(metadata, dict):
                metadata = {}
            metadata = {key: metadata.get(key) for key in ("name", "author", "license", "category", "version", "source") if metadata.get(key)}
            metadata["name"] = metadata.get("name") or prefix
            metadata["total"] = len(icons)
            catalog[prefix] = metadata
    if not catalog:
        raise ValueError("no valid icon sets found")
    real_total = sum(map(len, names.values()))
    if min_icons and real_total < min_icons:
        raise ValueError(f"insufficient icons for the declared FULL build: {real_total:,} < {min_icons:,}; no EXE should be built")
    (output / "index.json").write_text(json.dumps({"version": 1, "collections": catalog}, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    (output / "names.json.gz").write_bytes(gzip.compress(json.dumps(names, ensure_ascii=False, separators=(",", ":")).encode(), compresslevel=9, mtime=0))
    print(f"Bundled {sum(map(len, names.values())):,} identifiable icon names in {len(catalog)} packages")
    print(f"Compressed assets: {sum(f.stat().st_size for f in output.rglob('*.gz')) / 1048576:.2f} MiB")
    if skipped:
        print(f"Skipped {len(skipped)} invalid sets", file=sys.stderr)
        for item in skipped[:15]:
            print(" -", item, file=sys.stderr)
    return catalog, names


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", action="append", type=Path, default=[], help="directory containing IconifyJSON per-collection files")
    parser.add_argument("--output", type=Path, default=ROOT / "data")
    parser.add_argument("--clean", action="store_true", help="remove existing packaged collections first")
    parser.add_argument("--min-icons", type=int, default=0, help="fail the build if the resulting set has fewer identifiable names")
    args = parser.parse_args()
    make_package([ROOT / "raw"] + args.source, args.output, args.clean, args.min_icons)
