//go:build windows

package main

import (
	"bytes"
	"errors"
	"fmt"
	"image"
	"image/color"
	"image/png"
	"syscall"
	"time"
	"unsafe"
)

var (
	user32                   = syscall.NewLazyDLL("user32.dll")
	kernel32                 = syscall.NewLazyDLL("kernel32.dll")
	shell32                  = syscall.NewLazyDLL("shell32.dll")
	pOpenClipboard           = user32.NewProc("OpenClipboard")
	pCloseClipboard          = user32.NewProc("CloseClipboard")
	pEmptyClipboard          = user32.NewProc("EmptyClipboard")
	pSetClipboardData        = user32.NewProc("SetClipboardData")
	pRegisterClipboardFormat = user32.NewProc("RegisterClipboardFormatW")
	pGlobalAlloc             = kernel32.NewProc("GlobalAlloc")
	pGlobalLock              = kernel32.NewProc("GlobalLock")
	pGlobalUnlock            = kernel32.NewProc("GlobalUnlock")
	pGlobalFree              = kernel32.NewProc("GlobalFree")
	pSetAppUserModelID       = shell32.NewProc("SetCurrentProcessExplicitAppUserModelID")
)

func initializeWindowsIdentity() {
	name, _ := syscall.UTF16PtrFromString("Hashcod.Openicons.Desktop")
	if name != nil {
		pSetAppUserModelID.Call(uintptr(unsafe.Pointer(name)))
	}
}

func clipboardGlobal(data []byte) (uintptr, error) {
	handle, _, _ := pGlobalAlloc.Call(0x0002, uintptr(len(data))) // GMEM_MOVEABLE
	if handle == 0 {
		return 0, errors.New("no se pudo asignar memoria del portapapeles")
	}
	addr, _, _ := pGlobalLock.Call(handle)
	if addr == 0 {
		pGlobalFree.Call(handle)
		return 0, errors.New("GlobalLock falló")
	}
	copy(unsafe.Slice((*byte)(unsafe.Pointer(addr)), len(data)), data)
	pGlobalUnlock.Call(handle)
	return handle, nil
}

func bitmapDIB(src image.Image) ([]byte, error) {
	bounds := src.Bounds()
	w, h := bounds.Dx(), bounds.Dy()
	if w <= 0 || h <= 0 || w > 4096 || h > 4096 {
		return nil, errors.New("dimensiones PNG inválidas")
	}
	stride := w * 4
	data := make([]byte, 40+stride*h)
	put32 := func(n, v int) {
		data[n] = byte(v)
		data[n+1] = byte(v >> 8)
		data[n+2] = byte(v >> 16)
		data[n+3] = byte(v >> 24)
	}
	put32(0, 40)
	put32(4, w)
	put32(8, h)
	data[12] = 1
	data[14] = 32
	put32(20, stride*h)
	for y := 0; y < h; y++ {
		for x := 0; x < w; x++ {
			pixel := color.NRGBAModel.Convert(src.At(bounds.Min.X+x, bounds.Min.Y+y)).(color.NRGBA)
			i := 40 + (h-1-y)*stride + x*4
			data[i], data[i+1], data[i+2], data[i+3] = pixel.B, pixel.G, pixel.R, pixel.A
		}
	}
	return data, nil
}

func writePNGClipboard(data []byte) error {
	if len(data) < 8 || !bytes.Equal(data[:8], []byte{137, 80, 78, 71, 13, 10, 26, 10}) {
		return errors.New("contenido no es PNG")
	}
	img, err := png.Decode(bytes.NewReader(data))
	if err != nil {
		return fmt.Errorf("PNG inválido: %w", err)
	}
	dib, err := bitmapDIB(img)
	if err != nil {
		return err
	}
	// Windows registered PNG format preserves real transparency; CF_DIB is a fallback for legacy apps.
	name, _ := syscall.UTF16PtrFromString("PNG")
	cfPNG, _, _ := pRegisterClipboardFormat.Call(uintptr(unsafe.Pointer(name)))
	if cfPNG == 0 {
		return errors.New("no se pudo registrar PNG en Windows")
	}
	acquired := false
	for attempt := 0; attempt < 10; attempt++ {
		result, _, _ := pOpenClipboard.Call(0)
		if result != 0 {
			acquired = true
			break
		}
		time.Sleep(20 * time.Millisecond)
	}
	if !acquired {
		return errors.New("el portapapeles de Windows está ocupado")
	}
	defer pCloseClipboard.Call()
	ok, _, _ := pEmptyClipboard.Call()
	if ok == 0 {
		return errors.New("no se pudo limpiar el portapapeles")
	}
	copied := false
	for _, entry := range []struct {
		format uintptr
		data   []byte
	}{{cfPNG, data}, {8, dib}} {
		h, e := clipboardGlobal(entry.data)
		if e != nil {
			continue
		}
		r, _, _ := pSetClipboardData.Call(entry.format, h)
		if r != 0 {
			copied = true
		} else {
			pGlobalFree.Call(h)
		}
	}
	if !copied {
		return errors.New("Windows rechazó los formatos PNG y DIB")
	}
	return nil
}
